#include <iostream>

using namespace std;

#include "UnitTest++/src/UnitTest++.h"


int main() {
  UnitTest::RunAllTests();

	system("pause");
}

