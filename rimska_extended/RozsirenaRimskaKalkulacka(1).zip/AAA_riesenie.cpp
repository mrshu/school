#include <iostream>
#include <sstream>

using namespace std;

//#include "riesenie.h"

#if !defined( _RIESENIE_H_ )
#define _RIESENIE_H_
class RIMSKA_KALKULACKA {
  int konverziaRimskych(const string &rimskeCislo);
  string konvertNaRimske(int cislo);
  int kalkulackaArabska(char oper, int op1, int op2);
 public:
  string kalkulackaRimska(const string &vyraz);
};

const bool DUMMY_BOOL = false;
const int DUMMY_INT = 0;
const string DUMMY_STRING = "";

const string CISLO_MIMO = "Cislo mimo povolenych hodnot";
const string ZLY_VYRAZ = "Zly vstupny vyraz";
#endif

string RIMSKA_KALKULACKA::kalkulackaRimska(const string &vyr) {
  return DUMMY_STRING;
}
int RIMSKA_KALKULACKA::konverziaRimskych(const string &rimskeCislo) {
  return DUMMY_INT;
}
string RIMSKA_KALKULACKA::konvertNaRimske(int cislo) {
  return DUMMY_STRING;
}
int RIMSKA_KALKULACKA::kalkulackaArabska(char oper, int op1, int op2) {
  return DUMMY_INT;
}